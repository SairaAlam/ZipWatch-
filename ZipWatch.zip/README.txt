These are the machine learning code

inputdata was used to enter data into the database

lingradmajor/linnogradmajor was used to calculate the major crime predictions of the zipcodes

lingradminor/linnogradminor was used to calculate the minor crime predictions of the zipcodes

kmeans is the kmeans code

recommend is the kdtree code