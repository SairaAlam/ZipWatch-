from pymongo import MongoClient
import pickle
import matplotlib as plt
import numpy as np
import pandas as pd
from sklearn.neighbors import KDTree
client=MongoClient()
db=client.zipwatch

zipcodelist = [10013,10004,10006,10282,10038, 10002, 10003, 10009, 10011, 10010, 10001, 10016, 10022, 10019, 10036,
               10021, 10065,10025,10128, 10023, 10024, 10029,10035, 10027, 10026, 10031, 10030, 10039, 10032,
10040, 10454, 10455, 10459, 10451, 10462, 10472, 10473, 10456, 10468, 10466, 10475, 10457, 10460, 10469,
10463, 10467, 10458, 11224, 11229, 11235, 11214, 11210, 11204, 11219, 11203, 11226, 11209, 11220, 11236,
 11230, 11225, 11212, 11233, 11208, 11207, 11239, 11231, 11213, 11217, 11215, 11216, 11221,
11237, 11201, 11205, 11238, 11211, 11206, 11222, 11694, 11691, 11418, 11416, 11432, 11451, 11385, 11426,
               10461,11427, 11411, 11413, 11417, 11365, 11366, 11367, 11101, 11354, 11355, 11368, 11373, 11364, 11361, 11375,
               11412, 11434, 11436, 11103, 11106, 10312, 10304, 10306, 10301,10012,10007,10280,10005,10014,10017,10020,10028,10075,10162,10069,10037,10033,10034,10474,10452,10464,
             10465,10453,10470,10471,11223,11234,11218,11228,11232,11692,11693,11695,11697,11690,11415,11421,11419,11424,11423,11435,11405,11431,11433,11439,11499,11379,11381,11428
                ,11429,11422,11005,11001,11002,11004,11414,11425,11104,11377,11378,11109,11356,11357,11358,11359,11360,11351,11352,11386,11390,11380,11362,11363,11374,11430,11102
                ,11105,10044,11369,11370,11372,11371,10310,10308,10305,10307,10309]

sample=[]
xvalList=[]
yvalList=[]
zvalList=[]
for index in zipcodelist:
    cursor=db.majorcrimePred.find({"zipcode":index}).distinct("predict")
    cursor1=db.minorcrimePred.find({"zipcode":index}).distinct("predict")
    cursor3=db.rate.find({"zipcode":index}).distinct("rate")



    for item1 in cursor:
        for item2 in cursor1:
            for item3 in cursor3:
                list=(index,item1,item2,item3)
                sample.append(list)
samples=np.array(sample)

tree=KDTree(samples,leaf_size=2)
s=pickle.dumps(tree)
tree_copy=pickle.loads(s)
for item in samples:
    dist,index=tree_copy.query(item,k=3)
    indexes=np.array(index)

for item in zipcodelist:











